<?php
// Test database connection
echo "Testing database connection...\n\n";

try {
    $conn = new mysqli('localhost', 'root', '', 'hotel_booking_system');
    
    if ($conn->connect_error) {
        echo "ERROR: " . $conn->connect_error . "\n";
        exit(1);
    } 
    
    echo "SUCCESS: Connected to hotel_booking_system\n";
    
    // Test bot_prices table
    $result = $conn->query('SELECT COUNT(*) as count FROM bot_prices');
    if ($result) {
        $row = $result->fetch_assoc();
        echo "Bot prices count: " . $row['count'] . "\n";
    }
    
    // Test user authentication
    echo "\nTesting authentication method...\n";
    $result = $conn->query("SELECT user, plugin FROM mysql.user WHERE user='root'");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            echo "User: {$row['user']}, Plugin: {$row['plugin']}\n";
        }
    }
    
} catch (Exception $e) {
    echo "EXCEPTION: " . $e->getMessage() . "\n";
}
?>