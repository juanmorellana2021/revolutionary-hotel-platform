<?php
echo <h1>Ultimate Database Fix</h1>;

// Method 1: Try to fix using direct system calls
echo <h2>Method 1: System Command Fix</h2>;

 = [
    sudo mysql -e "DROP USER IF EXISTS hoteluser@localhost;",
    sudo mysql -e "DROP USER IF EXISTS  \hoteluser\'@\localhost\';",
    sudo mysql -e "CREATE DATABASE IF NOT EXISTS hotel_booking_system;",
    sudo mysql -e "CREATE USER hoteluser@localhost IDENTIFIED BY \hotelpass123\';",
    sudo mysql -e "GRANT ALL PRIVILEGES ON hotel_booking_system.* TO hoteluser@localhost;",
    sudo mysql -e "GRANT ALL PRIVILEGES ON *.* TO hoteluser@localhost WITH GRANT OPTION;",
    sudo mysql -e "FLUSH PRIVILEGES;"
];

foreach ( as ) {
    echo <p><strong>Running:</strong>  . htmlspecialchars() . </p>;
     = shell_exec( .  2>&1);
    echo <pre> . htmlspecialchars() . </pre>;
}

// Method 2: Test connection
echo <h2>Method 2: Connection Test</h2>;
try {
     = new PDO(mysql:host=localhost;dbname=hotel_booking_system, hoteluser, hotelpass123);
    ->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo <p style="color: green; font-size: 20px; font-weight: bold;"> CONNECTION SUCCESSFUL!</p>;
    
    // Create basic hotel tables
     = [
        CREATE TABLE IF NOT EXISTS users (
 id INT PRIMARY KEY AUTO_INCREMENT,
 first_name VARCHAR(100),
 last_name VARCHAR(100),
 email VARCHAR(255) UNIQUE,
 password VARCHAR(255),
 role ENUM(guest, manager, admin) DEFAULT guest,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
 ),
        CREATE TABLE IF NOT EXISTS rooms (
 id INT PRIMARY KEY AUTO_INCREMENT,
 room_number VARCHAR(20) UNIQUE,
 room_type VARCHAR(50),
 price_per_night DECIMAL(10,2),
 capacity INT,
 amenities TEXT,
 available BOOLEAN DEFAULT TRUE,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
 ),
        CREATE TABLE IF NOT EXISTS bookings (
 id INT PRIMARY KEY AUTO_INCREMENT,
 user_id INT,
 room_id INT,
 check_in_date DATE,
 check_out_date DATE,
 total_amount DECIMAL(10,2),
 status ENUM(pending, confirmed, cancelled, completed) DEFAULT pending,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (user_id) REFERENCES users(id),
 FOREIGN KEY (room_id) REFERENCES rooms(id)
 )
    ];
    
    foreach ( as ) {
        try {
            ->exec();
            echo <p style="color: green;"> Table created successfully</p>;
        } catch (Exception ) {
            echo <p style="color: orange;"> Table creation note:  . ->getMessage() . </p>;
        }
    }
    
    // Insert default users
     = [
        [manager@hotel.com, Manager, User, password, manager],
        [guest@hotel.com, Guest, User, password, guest],
        [admin@hotel.com, Admin, User, password, admin]
    ];
    
     = ->prepare(INSERT IGNORE INTO users (email, first_name, last_name, password, role) VALUES (?, ?, ?, ?, ?));
    
    foreach ( as ) {
         = password_hash([3], PASSWORD_DEFAULT);
        ->execute([[0], [1], [2], , [4]]);
        echo <p style="color: blue;"> User {[0]} ready</p>;
    }
    
    echo <p style="color: green; font-size: 18px; font-weight: bold;"> HOTEL BOOKING SYSTEM IS READY!</p>;
    echo <p><a href="/manage/" style="background: #007cba; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Go to Hotel Management System</a></p>;
    
} catch (PDOException ) {
    echo <p style="color: red; font-size: 18px;"> Connection still failed:  . ->getMessage() . </p>;
    
    // Method 3: Alternative connection attempts
    echo <h2>Method 3: Alternative Fixes</h2>;
    
    // Try different authentication methods
     = [
        sudo mysql -e "ALTER USER root@localhost IDENTIFIED WITH mysql_native_password BY \password123\';",
        sudo mysql -e "CREATE USER IF NOT EXISTS hoteluser@\%\' IDENTIFIED BY \hotelpass123\';",
        sudo mysql -e "GRANT ALL ON *.* TO hoteluser@\%\';",
        sudo mysql -e "FLUSH PRIVILEGES;"
    ];
    
    foreach ( as ) {
        echo <p><strong>Trying:</strong>  . htmlspecialchars() . </p>;
         = shell_exec( .  2>&1);
        echo <pre> . htmlspecialchars() . </pre>;
    }
    
    // Try connecting with alternative settings
    try {
         = new PDO(mysql:host=localhost;dbname=hotel_booking_system, hoteluser, hotelpass123);
        echo <p style="color: green;"> Alternative connection method worked!</p>;
    } catch (Exception ) {
        echo <p style="color: red;">Alternative method also failed:  . ->getMessage() . </p>;
        
        // Try root connection
        try {
             = new PDO(mysql:host=localhost, root, password123);
            echo <p style="color: blue;">Root connection available - creating user directly...</p>;
            ->exec(CREATE DATABASE IF NOT EXISTS hotel_booking_system);
            ->exec(CREATE USER IF NOT EXISTS hoteluser@localhost IDENTIFIED BY hotelpass123);
            ->exec(GRANT ALL ON hotel_booking_system.* TO hoteluser@localhost);
            ->exec(FLUSH PRIVILEGES);
            echo <p style="color: green;">User created via root connection!</p>;
        } catch (Exception ) {
            echo <p style="color: red;">Root connection failed:  . ->getMessage() . </p>;
        }
    }
}
?>
