<?php
/**
 * WhatsApp Hotel Bot - Hybrid Bot combining Node.js bot features with PHP hotel system
 * Integrates WhatsApp Business API with Revolutionary Hotel Platform
 */

require_once '../revolutionary-hotel-platform-github/db_connection.php';

class WhatsAppHotelBot {
    private $conn;
    private $accessToken;
    private $phoneNumberId;
    private $webhookToken;
    private $openaiApiKey;
    
    public function __construct() {
        global $conn;
        $this->conn = $conn;
        
        // WhatsApp Business API Configuration
        $this->accessToken = $this->getConfig('whatsapp_access_token') ?: 'YOUR_WHATSAPP_ACCESS_TOKEN';
        $this->phoneNumberId = $this->getConfig('whatsapp_phone_number_id') ?: 'YOUR_PHONE_NUMBER_ID';
        $this->webhookToken = $this->getConfig('whatsapp_webhook_token') ?: 'hotel_webhook_token_2025';
        
        // OpenAI Configuration (from your Node.js bot)
        $this->openaiApiKey = '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';
    }
    
    /**
     * Handle incoming messages (similar to your Node.js bot)
     */
    public function handleMessage($phoneNumber, $message) {
        $message = trim($message);
        $response = '';
        
        // Handle commands similar to your Node.js bot
        if (strpos($message, '!info') === 0) {
            $parts = explode(' ', $message);
            $clientId = isset($parts[1]) ? $parts[1] : null;
            $response = $this->getClientInfo($clientId, $phoneNumber);
            
        } elseif (strpos($message, '!update') === 0) {
            $parts = explode(' ', $message, 3);
            $clientId = isset($parts[1]) ? $parts[1] : null;
            $newInfo = isset($parts[2]) ? $parts[2] : '';
            $response = $this->updateClientInfo($clientId, $newInfo, $phoneNumber);
            
        } elseif (strpos($message, '!ask') === 0) {
            $prompt = trim(substr($message, 4));
            $response = $this->askOpenAI($prompt);
            
        // New hotel commands
        } elseif (strpos($message, '!disponibilidad') === 0) {
            $response = $this->checkAvailability($phoneNumber);
            
        } elseif (strpos($message, '!hotelcoins') === 0) {
            $response = $this->getHotelCoins($phoneNumber);
            
        } elseif (strpos($message, '!reservar') === 0) {
            $response = $this->startBookingProcess($phoneNumber);
            
        } elseif (strpos($message, '!estado') === 0) {
            $response = $this->getBookingStatus($phoneNumber);
            
        } elseif (strpos($message, '!ayuda') === 0 || strpos($message, '!help') === 0) {
            $response = $this->getHelpMessage();
            
        } else {
            // Default: Ask OpenAI with hotel context
            $response = $this->askOpenAIWithHotelContext($message, $phoneNumber);
        }
        
        // Send response via WhatsApp
        $this->sendWhatsAppMessage($phoneNumber, $response);
        
        // Log conversation
        $this->logConversation($phoneNumber, $message, $response);
        
        return $response;
    }
    
    /**
     * Get client info (adapted from your Node.js bot)
     */
    private function getClientInfo($clientId, $phoneNumber) {
        if (!$clientId) {
            return "Por favor proporciona un ID de cliente. Uso: !info [ID]";
        }
        
        // Try to find user by client ID or phone number
        $stmt = $this->conn->prepare("
            SELECT * FROM users 
            WHERE id = ? OR phone_number = ? OR whatsapp_number = ?
        ");
        $stmt->bind_param("sss", $clientId, $phoneNumber, $phoneNumber);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($user = $result->fetch_assoc()) {
            return sprintf(
                "📋 *Información del Cliente*\n\n" .
                "👤 *Nombre:* %s\n" .
                "📧 *Email:* %s\n" .
                "📱 *Teléfono:* %s\n" .
                "💰 *HotelCoins:* %s\n" .
                "⭐ *Puntos Lealtad:* %s",
                $user['full_name'] ?: 'No especificado',
                $user['email'] ?: 'No especificado',
                $user['phone_number'] ?: $phoneNumber,
                $this->getUserHotelCoins($user['id']),
                $this->getUserLoyaltyPoints($user['id'])
            );
        }
        
        return "❌ Cliente no encontrado con ID: $clientId";
    }
    
    /**
     * Update client info (adapted from your Node.js bot)
     */
    private function updateClientInfo($clientId, $newInfo, $phoneNumber) {
        if (!$clientId || !$newInfo) {
            return "Por favor proporciona ID y nueva información. Uso: !update [ID] [información]";
        }
        
        // Update user information
        $stmt = $this->conn->prepare("
            UPDATE users 
            SET notes = CONCAT(IFNULL(notes, ''), '\n', ?, ' - Actualizado via WhatsApp: ', NOW())
            WHERE id = ? OR phone_number = ? OR whatsapp_number = ?
        ");
        $stmt->bind_param("ssss", $newInfo, $clientId, $phoneNumber, $phoneNumber);
        
        if ($stmt->execute() && $stmt->affected_rows > 0) {
            return "✅ Información actualizada exitosamente para cliente: $clientId";
        }
        
        return "❌ No se pudo actualizar la información para cliente: $clientId";
    }
    
    /**
     * Ask OpenAI (from your Node.js bot)
     */
    private function askOpenAI($prompt) {
        if (empty($prompt)) {
            return "Por favor proporciona una pregunta. Uso: !ask [pregunta]";
        }
        
        $data = [
            'model' => 'gpt-3.5-turbo',
            'messages' => [
                [
                    'role' => 'user',
                    'content' => $prompt
                ]
            ],
            'max_tokens' => 500,
            'temperature' => 0.7
        ];
        
        $ch = curl_init('https://api.openai.com/v1/chat/completions');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $this->openaiApiKey
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200) {
            $result = json_decode($response, true);
            if (isset($result['choices'][0]['message']['content'])) {
                return "🤖 *ChatGPT responde:*\n\n" . trim($result['choices'][0]['message']['content']);
            }
        }
        
        return "❌ No pude obtener respuesta de ChatGPT. Intenta más tarde.";
    }
    
    /**
     * Ask OpenAI with hotel context
     */
    private function askOpenAIWithHotelContext($message, $phoneNumber) {
        $user = $this->getOrCreateUser($phoneNumber);
        
        $hotelContext = "Eres un asistente de hotel inteligente. Ayudas con reservas, información del hotel, HotelCoins y servicios. ";
        $hotelContext .= "El usuario puede usar comandos como !disponibilidad, !hotelcoins, !reservar, !estado, !ayuda. ";
        $hotelContext .= "Si el mensaje no es un comando, responde de manera útil sobre temas de hotel.";
        
        $prompt = $hotelContext . "\n\nUsuario: " . $message;
        
        return $this->askOpenAI($prompt);
    }
    
    /**
     * Check room availability
     */
    private function checkAvailability($phoneNumber) {
        // Get available rooms for today and next 7 days
        $stmt = $this->conn->prepare("
            SELECT r.*, rt.type_name, rt.base_price 
            FROM rooms r 
            JOIN room_types rt ON r.room_type_id = rt.id 
            WHERE r.status = 'available' 
            AND r.id NOT IN (
                SELECT room_id FROM bookings 
                WHERE status IN ('confirmed', 'checked_in') 
                AND check_out_date >= CURDATE()
            )
            ORDER BY rt.base_price ASC
            LIMIT 5
        ");
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            return "❌ No hay habitaciones disponibles en este momento.\n\n💬 Escribe !reservar para consultar fechas específicas.";
        }
        
        $response = "🏨 *Habitaciones Disponibles*\n\n";
        while ($room = $result->fetch_assoc()) {
            $response .= sprintf(
                "🛏️ *%s*\n" .
                "   💰 Precio: $%.2f/noche\n" .
                "   🏷️ Habitación: %s\n\n",
                $room['type_name'],
                $room['base_price'],
                $room['room_number']
            );
        }
        
        $response .= "📱 Escribe *!reservar* para hacer una reserva\n";
        $response .= "💰 Escribe *!hotelcoins* para ver tu saldo";
        
        return $response;
    }
    
    /**
     * Get HotelCoins balance
     */
    private function getHotelCoins($phoneNumber) {
        $user = $this->getOrCreateUser($phoneNumber);
        $hotelcoins = $this->getUserHotelCoins($user['id']);
        $loyaltyPoints = $this->getUserLoyaltyPoints($user['id']);
        
        $response = "💰 *Tu Wallet HotelCoin*\n\n";
        $response .= "🪙 *HotelCoins:* $hotelcoins\n";
        $response .= "⭐ *Puntos Lealtad:* $loyaltyPoints\n\n";
        $response .= "💡 *¿Sabías que?*\n";
        $response .= "• Ganas 1% en HotelCoins por cada reserva\n";
        $response .= "• Los puntos se pueden canjear por descuentos\n";
        $response .= "• Puedes transferir HotelCoins a otros usuarios\n\n";
        $response .= "📱 Escribe *!reservar* para ganar más coins";
        
        return $response;
    }
    
    /**
     * Start booking process
     */
    private function startBookingProcess($phoneNumber) {
        return "🏨 *Proceso de Reserva*\n\n" .
               "Para hacer una reserva, necesito:\n\n" .
               "📅 *Fecha de entrada*\n" .
               "📅 *Fecha de salida*\n" .
               "👥 *Número de huéspedes*\n" .
               "🛏️ *Tipo de habitación preferida*\n\n" .
               "💬 Responde con esta información:\n" .
               "Ejemplo: *Reserva del 25/12/2025 al 30/12/2025 para 2 personas*\n\n" .
               "🤖 O escribe tu solicitud en lenguaje natural y yo te ayudo.";
    }
    
    /**
     * Get booking status
     */
    private function getBookingStatus($phoneNumber) {
        $user = $this->getOrCreateUser($phoneNumber);
        
        $stmt = $this->conn->prepare("
            SELECT b.*, r.room_number, rt.type_name 
            FROM bookings b
            LEFT JOIN rooms r ON b.room_id = r.id
            LEFT JOIN room_types rt ON r.room_type_id = rt.id
            WHERE b.user_id = ? 
            ORDER BY b.created_at DESC 
            LIMIT 3
        ");
        $stmt->bind_param("i", $user['id']);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            return "📋 No tienes reservas registradas.\n\n📱 Escribe *!reservar* para hacer tu primera reserva.";
        }
        
        $response = "📋 *Tus Reservas*\n\n";
        while ($booking = $result->fetch_assoc()) {
            $statusEmoji = $this->getStatusEmoji($booking['status']);
            $response .= sprintf(
                "%s *Reserva #%d*\n" .
                "🛏️ %s - Habitación %s\n" .
                "📅 %s al %s\n" .
                "💰 Total: $%.2f\n\n",
                $statusEmoji,
                $booking['id'],
                $booking['type_name'] ?: 'Habitación',
                $booking['room_number'] ?: 'TBD',
                date('d/m/Y', strtotime($booking['check_in_date'])),
                date('d/m/Y', strtotime($booking['check_out_date'])),
                $booking['total_amount']
            );
        }
        
        return $response;
    }
    
    /**
     * Get help message
     */
    private function getHelpMessage() {
        return "🤖 *Bot del Hotel - Comandos Disponibles*\n\n" .
               "📋 *Información*\n" .
               "• `!info [ID]` - Ver info de cliente\n" .
               "• `!update [ID] [info]` - Actualizar cliente\n\n" .
               "🏨 *Hotel*\n" .
               "• `!disponibilidad` - Ver habitaciones\n" .
               "• `!reservar` - Hacer reserva\n" .
               "• `!estado` - Ver mis reservas\n" .
               "• `!hotelcoins` - Ver mi wallet\n\n" .
               "🤖 *IA*\n" .
               "• `!ask [pregunta]` - Preguntar a ChatGPT\n" .
               "• O simplemente escribe tu pregunta\n\n" .
               "💡 *Tip:* También puedes escribir en lenguaje natural y yo te entenderé.";
    }
    
    // Helper methods
    private function getOrCreateUser($phoneNumber) {
        $stmt = $this->conn->prepare("
            SELECT * FROM users 
            WHERE phone_number = ? OR whatsapp_number = ?
        ");
        $stmt->bind_param("ss", $phoneNumber, $phoneNumber);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($user = $result->fetch_assoc()) {
            return $user;
        }
        
        // Create new user
        $stmt = $this->conn->prepare("
            INSERT INTO users (whatsapp_number, phone_number, full_name, created_at) 
            VALUES (?, ?, ?, NOW())
        ");
        $name = "Usuario WhatsApp";
        $stmt->bind_param("sss", $phoneNumber, $phoneNumber, $name);
        $stmt->execute();
        
        return [
            'id' => $this->conn->insert_id,
            'whatsapp_number' => $phoneNumber,
            'phone_number' => $phoneNumber,
            'full_name' => $name
        ];
    }
    
    private function getUserHotelCoins($userId) {
        $stmt = $this->conn->prepare("
            SELECT COALESCE(SUM(amount), 0) as balance 
            FROM hotelcoin_transactions 
            WHERE user_id = ?
        ");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return number_format($row['balance'], 2);
    }
    
    private function getUserLoyaltyPoints($userId) {
        $stmt = $this->conn->prepare("
            SELECT COALESCE(SUM(points), 0) as points 
            FROM loyalty_transactions 
            WHERE user_id = ?
        ");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return number_format($row['points'], 0);
    }
    
    private function getStatusEmoji($status) {
        $emojis = [
            'pending' => '⏳',
            'confirmed' => '✅',
            'checked_in' => '🏨',
            'checked_out' => '✈️',
            'cancelled' => '❌'
        ];
        return $emojis[$status] ?? '📋';
    }
    
    private function getConfig($key) {
        $stmt = $this->conn->prepare("
            SELECT config_value FROM ai_chat_config 
            WHERE config_key = ?
        ");
        $stmt->bind_param("s", $key);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            return $row['config_value'];
        }
        return null;
    }
    
    private function sendWhatsAppMessage($phoneNumber, $message) {
        // Here you would implement WhatsApp Business API sending
        // For now, we'll just return the message (for testing)
        return $message;
    }
    
    private function logConversation($phoneNumber, $message, $response) {
        $stmt = $this->conn->prepare("
            INSERT INTO whatsapp_conversations 
            (phone_number, message, response, created_at) 
            VALUES (?, ?, ?, NOW())
        ");
        $stmt->bind_param("sss", $phoneNumber, $message, $response);
        $stmt->execute();
    }
}

// Test the bot (you can remove this later)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (isset($input['phone']) && isset($input['message'])) {
        $bot = new WhatsAppHotelBot();
        $response = $bot->handleMessage($input['phone'], $input['message']);
        
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'response' => $response
        ]);
    }
}
?>