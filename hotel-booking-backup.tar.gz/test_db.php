<?php
echo <h1>Database Connection Test</h1>;

// Test with current credentials
try {
     = new PDO(mysql:host=localhost;dbname=hotel_booking_system, hoteluser, hotelpass123);
    echo <p style="color: green;"> Database connection successful!</p>;
    
    // Test creating a simple table
    ->exec(CREATE TABLE IF NOT EXISTS test_table (id INT PRIMARY KEY, name VARCHAR(100)));
    echo <p style="color: green;"> Table creation successful!</p>;
    
} catch (PDOException ) {
    echo <p style="color: red;"> Database connection failed:  . ->getMessage() . </p>;
    
    // Try to connect as root to fix the issue
    try {
         = new PDO(mysql:host=localhost, root, ");
        echo <p style="color: blue;">Root connection available - attempting to fix user...</p>;
        
        ->exec(DROP USER IF EXISTS hoteluser@localhost);
        ->exec(CREATE USER hoteluser@localhost IDENTIFIED BY "hotelpass123");
        ->exec(GRANT ALL PRIVILEGES ON hotel_booking_system.* TO hoteluser@localhost);
        ->exec(FLUSH PRIVILEGES);
        
        echo <p style="color: green;"> User created successfully!</p>;
        
        // Test again
         = new PDO(mysql:host=localhost;dbname=hotel_booking_system, hoteluser, hotelpass123);
        echo <p style="color: green;"> Fixed connection works!</p>;
        
    } catch (PDOException ) {
        echo <p style="color: red;"> Root connection also failed:  . ->getMessage() . </p>;
    }
}
?>
